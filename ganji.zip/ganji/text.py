#获取每一条帖子详情 用于测试
import requests
import time
from bs4 import BeautifulSoup

headers = {
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36',
    'Connection':'keep-alive'
}
proxies = {'http':'http://211.167.112.14:80'}

def get_info_from(page_url):
    wb_data = requests.get(page_url,headers=headers,proxies=proxies)
    wb_data.encoding = 'utf-8'
    soup=BeautifulSoup(wb_data.text,'lxml')
    title = soup.title.text.strip() #标题
    date = soup.select('i.pr-5')[0].text.strip().split(' ')[0] if soup.find_all('i','pr-5') else None
    price = soup.select('i.f22.fc-orange.f-type')[0].text.strip() if soup.find_all('i','fc-orange') else None
    address = list(map(lambda x:x.text,soup.select( 'ul.det-infor > li:nth-of-type(3) > a')))
    #类型
    genre = list(map(lambda x:x.text,soup.select('div.leftBox > div:nth-of-type(3) > div > ul > li:nth-of-type(1) > span > a')))
    #新旧程度
    old = soup.select('div.det-summary > div:nth-of-type(1) > div:nth-of-type(1) > ul.second-det-infor.clearfix > li')[0].text.replace('\n ','').replace(' ','') if soup.find_all('ul','second-det-infor',' clearfix') else None

   #wrapper > div.content.clearfix > div.leftBox > div:nth-child(4) > div.det-summary > div:nth-child(1) > div:nth-child(1) > ul.second-det-infor.clearfix > li
    if wb_data.status_code == 404:
        pass
    else:
        data = {
            'title':title,
            'date':date,
            'price':price,
            'address':address,
            'url':page_url,
            'genre':genre,
            'old':old
        }
        time.sleep(5)
        print(data)

get_info_from('http://bj.ganji.com/shouji/1998976602x.htm')

