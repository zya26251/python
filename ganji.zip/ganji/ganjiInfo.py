import random
import requests
from bs4 import BeautifulSoup
import pymongo
import time


client = pymongo.MongoClient('localhost',27017)
ganji = client['ganji']
url_list = ganji['url_list']
item_info = ganji['item_info']

headers = {
    'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.110 Safari/537.36',
    'Connection':'keep-alive'
}
# http://cn-proxy.com/
proxy_list = [
    'http://112.195.84.165:9000',
    'http://114.224.129.82:8090',
    'http://115.218.127.129:9000',
    'http://115.151.233.173:9000'
    ]
proxy_ip = random.choice(proxy_list) # 随机获取代理ip
# print(proxy_ip)
proxies = {'http':'http://211.167.112.14:80'}

#获取每一页的链接
def get_links_from(channel,pages,who_shells='o'):
    # http://bj.ganji.com/shouji/o2/
    # channel=http://bj.ganji.com/shouji/
    url = '{}{}{}/'.format(channel,str(who_shells),str(pages))
    wb_data = requests.get(url,headers=headers,proxies=proxies)
    soup = BeautifulSoup(wb_data.text,'lxml')
    time.sleep(5)
    if soup.find('ul','pageLink'):
        links = soup.select('dd.feature > div > ul > li > a')
        for link in links:
            url_link = link.get('href')
            if 'zhuanzhuan' not in url_link and 'click' not in url_link:
                url_list.insert_one({'url_link':url_link})
                print(url_link)
    else:
        pass
#get_links_from('http://bj.ganji.com/jiaju/',2)
#page_url= 'http://bj.ganji.com/shouji/1973419020x.htm'

#获取每一条帖子详情
def get_info_from(page_url):
    wb_data = requests.get(page_url,headers=headers,proxies=proxies)
    wb_data.encoding = 'utf-8'
    soup=BeautifulSoup(wb_data.text,'lxml')
    title = soup.title.text.strip()
    date = soup.select('i.pr-5')[0].text.strip().split(' ')[0] if soup.find_all('i','pr-5') else None
    price = soup.select('i.f22.fc-orange.f-type')[0].text.strip() if soup.find_all('i','fc-orange') else None
    address = list(map(lambda x:x.text,soup.select( 'ul.det-infor > li:nth-of-type(3) > a')))
     #类型
    genre = list(map(lambda x:x.text,soup.select('div.leftBox > div:nth-of-type(3) > div > ul > li:nth-of-type(1) > span > a')))
    #新旧程度
    old = soup.select('div.det-summary > div:nth-of-type(1) > div:nth-of-type(1) > ul.second-det-infor.clearfix > li')[0].text.replace('\n ','').replace(' ','') if soup.find_all('ul','second-det-infor',' clearfix') else None
    #genre = soup.select('div.col_sub.sumary > ul > li:nth-of-type(3) > div.su_con > span.c_25d > a')[0].text if soup._find_all('ul','det-infor') else None
    if wb_data.status_code == 404:
        pass
    else:
        data = {
            'title':title,
            'date':date,
            'price':price,
            'address':address,
            'url':page_url,
            'genre':genre,
            'old':old
        }
        item_info.insert_one(data)
        time.sleep(5)
        print(data)

#get_info_from(page_url)
