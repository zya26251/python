from ganjiInfo import get_info_from,url_list
from ganjiInfo import get_links_from,item_info
from channel import channel
from multiprocessing import Pool
import pymongo


#url = ['http://bj.ganji.com/wu/']
channels = [item['channel'] for item in channel.find()] #数据库中的类型链接
all_links = [item['url_link'] for item in url_list.find()]#数据库中每个帖子的链接
page_url = [item['url'] for item in item_info.find()]#已经存入数据库的详情中url,和all_links中url匹配
x = set(all_links)
y = set(page_url)
rest_of_urls = x-y

#print(rest_of_urls)



def all_links_from(channel):
    for i in range(1,4):
        #print(channel)
        get_links_from(channel,i)

# def all_links_from(channels):
#     for channel in channels:
#         for i in range(1,2):
#             print(channel)
#             get_links_from(channel,i)

#get_all_info(all_links)


#print(channels)

if __name__ == '__main__':
    pool=Pool()
    pool.map(all_links_from,channels)
    print(len(all_links))
    #pool.map(get_info_from,rest_of_urls)
    pool.close()
    pool.join()